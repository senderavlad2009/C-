#include <stdio.h>
main()
{
	puts("        /|");
	puts("       / |");
	puts("      /  |");
	puts("     /___|");
	puts("  _______|________");
	puts(" |               /");
	puts(" |              /");
	puts(" |_____________/");

	
}
