#include <stdio.h>
#include <locale.h>
void main()
{
	setlocale(LC_CTYPE, "RUS");
	puts("���� ��������");
	getchar();
	puts(" __          __     __   __   ___   __    ");
	puts("|  |  |    | __|    __| |  | |  |  |__|        ");
	puts("|__|  |    | |__    |__ |__| |__|   __|        ");
	
}